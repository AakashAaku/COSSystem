﻿namespace CSOSytem.Core
{
    public class Class1
    {

    }
}
