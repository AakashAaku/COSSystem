﻿namespace CSOSystem.Data
{
    public class Class1
    {

    }
}
